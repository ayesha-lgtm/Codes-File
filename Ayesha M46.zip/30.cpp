  
      1
        2
           3 
              4
           5
        6 
     7     
     
     
     #include <iostream>
using namespace std;

int main() {
    int n = 4; // Number of rows in the upper half of the pattern
    int num = 1; // Starting number

    // Upper half of the pattern
    for (int i = 1; i <= n; i++) {
        // Print leading spaces
        for (int j = 1; j < i; j++) {
            cout << "  "; // Two spaces for alignment
        }
        // Print the number
        cout << num << endl;
        num++;
    }

    // Lower half of the pattern
    for (int i = n - 1; i >= 1; i--) {
        // Print leading spaces
        for (int j = 1; j < i; j++) {
            cout << "  "; // Two spaces for alignment
        }
        // Print the number
        cout << num << endl;
        num++;
    }

    return 0;
}