13579
1113151719
2123252729
3133353739
4143454749

#include <iostream>
using namespace std;

int main() {
    int count = 1;

    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= 5; j++) {
            if (j % 2 == 0) {
                cout << count << count + 1;
                count += 2;
            } else {
                cout << count;
                count++;
            }
            cout << " ";
        }
        cout << endl;
    }

    return 0;
}
