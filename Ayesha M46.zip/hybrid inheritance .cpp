
#include <iostream>
using namespace std;

class Animal {
    public:
        void eat() {
            cout << "Eating..." << endl;
        }
};

class Mammal : public Animal {
    public:
        void walk() {
            cout << "Walking..." << endl;
        }
};

class Pet {
    public:
        void play() {
            cout << "Playing..." << endl;
        }
};

class Dog : public Mammal, public Pet {
    public:
        void bark() {
            cout << "Barking..." << endl;
        }
};

int main() {
    Dog myDog;
    myDog.eat();
    myDog.walk();
    myDog.play();
    myDog.bark();
    return 0;
}
