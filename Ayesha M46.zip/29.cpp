  
      *
        *
           * 
              *
           *
        * 
     *     
     
     #include <iostream>
using namespace std;

int main() {
    int n = 4; // Number of rows in the upper half of the pattern

    // Upper half of the pattern
    for (int i = 1; i <= n; i++) {
        // Print leading spaces
        for (int j = 1; j < i; j++) {
            cout << " ";
        }
        // Print the asterisk
        cout << "*" << endl;
    }

    // Lower half of the pattern
    for (int i = n - 1; i >= 1; i--) {
        // Print leading spaces
        for (int j = 1; j < i; j++) {
            cout << " ";
        }
        // Print the asterisk
        cout << "*" << endl;
    }

    return 0;
}