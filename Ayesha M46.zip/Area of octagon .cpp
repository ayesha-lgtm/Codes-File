
#include <iostream>
using namespace std;

double areaOfOctagon(double sideLength) {
    const double tan22_5 = 0.41421356;
    return 2 * (1 + tan22_5) * sideLength * sideLength;
}

int main() {
    double sideLength;
    cout << "Enter the side length of the octagon: ";
    cin >> sideLength;
    cout << "Area of the octagon: " << areaOfOctagon(sideLength) << endl;
    return 0;
}
