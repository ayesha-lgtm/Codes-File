
246810
1214161820
2224262830
3234363840
4244464850

#include <iostream>
using namespace std;

int main() {
    int count = 2;

    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= 5; j++) {
            cout << count;
            count += 2;
        }
        cout << endl;
        count = i * 2 + 2;
    }

    return 0;
}
