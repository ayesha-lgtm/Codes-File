
#include <iostream>
using namespace namespace std;

class Shape {
    public:
        virtual void draw() = 0; // Pure virtual function
        virtual ~Shape() {} // Virtual destructor
};

class Circle : public Shape {
    public:
        void draw() override {
            cout << "Drawing a circle." << endl;
        }
};

class Rectangle : public Shape {
    public:
        void draw() override {
            cout << "Drawing a rectangle." << endl;
        }
};

int main() {
    Shape* circle = new Circle();
    Shape* rectangle = new Rectangle();

    circle->draw();
    rectangle->draw();

    delete circle;
    delete rectangle;

    return 0;
}
