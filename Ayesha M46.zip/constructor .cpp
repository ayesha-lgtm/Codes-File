
#include <iostream>
using namespace std;

class Person {
    private:
        string name;
        int age;
    public:
        // Constructor
        Person(string n, int a) {
            name = n;
            age = a;
        }

        // Display details
        void display() {
            cout << "Name: " << name << endl;
            cout << "Age: " << age << endl;
        }
};

int main() {
    Person p("John Doe", 30);
    p.display();
    return 0;
}
