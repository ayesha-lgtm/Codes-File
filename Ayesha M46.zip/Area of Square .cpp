
#include <iostream>
using namespace std;

int main() {
    float side;

    cout << "Enter the side of the square: ";
    cin >> side;

    float area = side * side;

    cout << "The area of the square is: " << area << endl;

    return 0;
}
