55555
 4  4
  3 3
   22
    1
    
#include <iostream>
using namespace std;

int main() {
    int numbers[] = {5, 5, 5, 5, 5, 4, 4, 3, 3, 2, 2, 1};
    int n = sizeof(numbers) / sizeof(numbers[0]);

    int count = 0;
    for (int i = 0; i < n; i++) {
        cout << numbers[i];
        count++;
        if (count == 5 || i == n - 1) {
            cout << endl;
            count = 0;
        } else {
            cout << " ";
        }
    }

    return 0;
}