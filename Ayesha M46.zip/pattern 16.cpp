12345
 2  5
  3 5
   45
    5
  
#include <iostream>
using namespace std;

int main() {
    int n = 5; // Number of rows

    for (int i = 1; i <= n; i++) {
        // Print leading spaces
        for (int j = 1; j < i; j++) {
            cout << " ";
        }

        // Print the number
        cout << i;

        // Print trailing spaces and numbers
        for (int j = i + 1; j <= n; j++) {
            cout << " ";
        }

        // Print the last number in the row
        if (i != n) {
            cout << n;
        }

        cout << endl;
    }

    return 0;
}
