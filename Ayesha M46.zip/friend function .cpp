
#include <iostream>
using namespace std;

class Distance {
    private:
        int meters;
    public:
        Distance(int m) {
            meters = m;
        }
        friend void display(Distance);
};

void display(Distance d) {
    cout << "Distance: " << d.meters << " meters" << endl;
}

int main() {
    Distance d(10);
    display(d);
    return 0;
}
