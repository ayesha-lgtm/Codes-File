
#include <iostream>
using namespace std;

void printDiamond(int n) {
    
    for (int i = 0; i < n; i++) {
        // Print spaces
        for (int j = 0; j < n - i - 1; j++) {
            cout << " ";
        
        for (int k = 0; k <= i; k++) {
            cout << "* ";
        }
        cout << endl;
    }

    for (int i = n - 2; i >= 0; i--) {
        // Print spaces
        for (int j = 0; j < n - i - 1; j++) {
            cout << " ";
        }
        
        for (int k = 0; k <= i; k++) {
            cout << "* ";
        }
        cout << endl;
    }
}

int main() {
    int n;
    cout << "Enter the number of rows: ";
    cin >> n;
    printDiamond(n);
    return 0;
}
