
#include <iostream>
using namespace std;

int main() {
    float d1, d2;

    cout << "Enter the length of diagonal 1: ";
    cin >> d1;

    cout << "Enter the length of diagonal 2: ";
    cin >> d2;

    float area = 0.5 * d1 * d2;

    cout << "The area of the rhombus is: " << area << endl;

    return 0;
}
