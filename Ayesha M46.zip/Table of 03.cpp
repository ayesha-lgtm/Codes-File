
#include <iostream>
using namespace std;

int main() {
    int num = 3;
    int limit = 10;

    cout << "Multiplication Table of " << num << endl;
    for (int i = 1; i <= limit; i++) {
        cout << num << " * " << i << " = " << num * i << endl;
    }

    return 0;
}
