12345
678910
1112131415
1617181920
2122232425

#include <iostream>
using namespace std;

int main() {
    int count = 1;

    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= 5; j++) {
            cout << count << " ";
            count++;
        }
        cout << endl;
    }

    return 0;
}
