
#include <iostream>
using namespace std;

int main() {
    int rows;
    cout << "Enter the number of rows: ";
    cin >> rows;

    int a = 0, b = 1;
    cout << a << endl;
    if (rows > 1) {
        cout << b << endl;
    }

    for (int i = 3; i <= rows; i++) {
        int temp = a + b;
        a = b;
        b = temp;

        for (int j = 1; j < i; j++) {
            cout << temp << " ";
            temp = temp - j;
        }
        cout << endl;
    }

    return 0;
    }