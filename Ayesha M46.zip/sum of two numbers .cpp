Sum of two numbers 


#include<iostream>
using namespace std;

int main()
{
int a;
int b;
cout<<"enter first number"<<endl;
cin>>a;
cout<<"enter second number"<<endl;
cin>>b;
cout<<"the sum is"<<a+b<<endl;

return 0;
}

         