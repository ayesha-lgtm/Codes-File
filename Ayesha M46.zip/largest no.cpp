Print largest number 


#include<iostream>
using namespace std;
int main ()
{
int a,b;
cout<<"enter two numbers"<<endl;
cin>>a,b;
if(a>b);
cout<<"largest number is"<<endl;
(b>a);
cout<<"smallest number is"<<endl;
return 0;
}

         