
#include <iostream>
using namespace std;

int main() {
    int rows;
    cout << "Enter the number of rows: ";
    cin >> rows;

    char ch[] = {'A', 'B', 'C'};
    int k = 0;
    for (int i = rows; i >= 1; i--) {
        for (int j = 1; j <= i; j++) {
            cout << ch[k] << " ";
            k = (k + 1) % 3;
        }
        cout << endl;
    }

    return 0;
}
