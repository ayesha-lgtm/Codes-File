   E       E
    D     D
     C   C
      B B
       A
      


#include <iostream>
using namespace std;

int main() {
    char ch = 'E';
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 2; j++) {
            cout << ch;
        }
        ch--;
    }
    return 0;
}
