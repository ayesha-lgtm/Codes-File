
#include <iostream>
using namespace std;

int modulus(int a, int b) {
    return a - (b * (a / b));
}

int main() {
    int a, b;
    cout << "Enter dividend: ";
    cin >> a;
    cout << "Enter divisor: ";
    cin >> b;
    cout << "Remainder: " << modulus(a, b) << endl;
    return 0;
}
