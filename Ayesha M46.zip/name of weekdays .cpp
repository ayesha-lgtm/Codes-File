#include<iostream>
using namespace std;
int main()
{
int day;
 cout<<"enter number of weekday"<<endl;
 cin>>day;
 switch (day)
 {
 
 case 1:
 cout<<"monday"<<endl;
 'break';
 case 2:
 cout<<"tuesday"<<endl;
 'break';
 case 3:
 cout<<"Wednesday"<<endl;
 'break';
 case 4:
 cout<<"Thursday"<<endl;
 'break';
 case 5:
 cout<<"Friday"<<endl;
 'break';
 case 6:
 cout<<"Saturday"<<endl;
 'break';
 case 7:
 cout<<"Sunday"<<endl;
 'break';
 'default';
 cout<<"invalid number"<<endl;
 'break';
 }
 return 0;
 }
                              


 


#include<iostream>
using namespace std;
 int main()
{
  int a,b,sum;
  cout<<"enter first numbers"<<endl;
  cin>>a;
  cout<<"enter second number"<<endl;
  cin>>b;
  sum = a + b;
  return 0;
  }
  
  
  
  
  
  
  
  
  
  
#include<iostream>
using namespace std;
int main()
{
  int n;
  cout<<"enter a number"<<endl;
  cin>>n;
  if(n%2==0)
  cout<<"number is even"<<endl;
  else
  cout<<"number is odd";
  return 0;
  }
  
  
  
  
  
  
  
  
  
  
    
  
#include<iostream>
using namespace std;
int main()
{
  int a,b,c,maximum;
  cout << "enter three numbers" << endl;
  cin >> a,b,c;
  maximum = a;
  if(b > maximum)
  maximum = b;
  if(c > maximum)
  maximum = c;
  cout << "maximum number is";
  return 0;
  }
  
  
  
  
  
  
  
  
    
#include<iostream>
using namespace std;
int main()
{
  int y;
  cout<<"enter a year"<<endl;
  cin>>y;
  if(y%4==0)
  cout<<"year is leap"<<endl;
  else
  cout<<"year is not leap";
  return 0;
  }
  
  
  
  
  
  
  
      
#include<iostream>
using namespace std;
int main()    
{
 int n,c,f;
 c = 1;
 f = 1;
 cout<<"enter a number"<<endl;
 cin>>n;
 while (c<=n)
 f = f * c;
 c = c + 1;
 cout<<"fictorial is:";
 return 0;
 }
 
 
 
 
 
 
 
 
 
 #include<iostream>
using namespace std;
int main()  
{
  int n;
  n = 1;
  while (n<=10)
  cout<<"n"<<endl;
  n = n + 1;
  return 0;
 }
 
 
 
 
 
 
 
 
 
  #include<iostream>
  using namespace std;
  int main() 
  {
     float cel, faren;
     cout<<"enter temperature in Celsius"<<endl;
     cin>>cel;
     faren = 9.0/5.0 * cel + 32;
     cout<<"temperature in Fahrenheit is:";
     return 0;
     }











  #include<iostream>
  using namespace std;
  int main() 
  {
    string str, reversed;
    cout<<"enter string"<<endl;
    cin>>str;
    for(int i = str.length(); i>=0;i--)
    reversed = str[i];
    cout<<"reversed string:"<<reversed;
    return 0;
    }
  
  
  
  
  
  
  
  
  
  
  #include<iostream>
  using namespace std;
  int main()
  {
     int n;
     cout<<"enter marks"<<endl;
     cin>>n;
     if (n>=40)
     cout<<"pass";
     else 
     cout<<"fail";
     return 0;
     }










  #include<iostream>
  using namespace std;
  
  int main()
  {
       
   int a,b,c, minimum;
  cout << "enter three numbers" << endl;
  cin >> a,b,c;
  minimum = a;
  if(b < minimum)
  minimum = b;
  if(c < minimum)
  minimum = c;
  cout << "minimum number is";
  return 0;
  }
  
  
  
  
  
  
  
  
  
  
  
    #include<iostream>
    using namespace std;
    int main()
    { 
       int a,b;
       cout<<"enter two numbers"<<endl;
       cin>>a,b;
       if (a>b)
       cout<<"largest number is:";
       else 
       cout<<"largest number is:";
       return 0;
       }
  
 
 
 
 
 
 
 
 
 
 #include<iostream>
 using namespace std;
 int main()
 {
   int marks;
   cout<<"enter marks"<<endl;
   cin>>marks;
   if(marks>=90)
   cout<<"Grade is A"<<endl;
   else if(marks>=75&&marks<=89)
   cout<<"Grade is B"<<endl;
   else if(marks>=60&&marks<=74)
   cout<<"Grade is C"<<endl;
   else if(marks>=50&&marks<=59)
   cout<<"Grade is D";
   else 
   cout<<"Grade is F";
   return 0;
   }
 
 
 
 
 
 
 
 
 
 
 
 
  #include<iostream>
 using namespace std;
 int main()
 {
   int age;
   cout<<"enter age"<<endl;
   cin>>age;
   if(age==18)
   cout<<"eligible for vote"<<endl;
   else 
   cout<<"not eligible for vote";
   return 0;
   }
   
   
   
   
   
   
   
   
   
   
   
   
     #include<iostream>
 using namespace std;
 int main()
 {
   int time;
   cout<<"enter time"<<endl;
   cin>>time;
   if(time>=6&&time<=18)
   cout<<"it is day time";
   else
   cout<<"it is night time";
   return 0;
   }
   
   
   
   
   
   
   
   
   
      
     #include<iostream>
 using namespace std;
 int main()
 {
   int amount;
   cout<<"enter amount"<<endl;
   cin>>amount;
   if(amount<100)
   cout<<"no discount"<<endl;
   else if (amount>=100&&amount<=500)
   cout<<"10% discount";
   else 
   cout<<"20% discount";
   return 0;
   }