
#include <iostream>
using namespace std;

void printArrowPattern(int n) {
    // Print upper half of the arrow
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            cout << " ";
        }
        for (int k = 0; k <= i; k++) {
            cout << "* ";
        }
        cout << endl;
    }

    // Print lower half of the arrow
    for (int i = n - 2; i >= 0; i--) {
        for (int j = 0; j < n - i - 1; j++) {
            cout << " ";
        }
        for (int k = 0; k <= i; k++) {
            cout << "* ";
        }
        cout << endl;
    }

    // Print the base of the arrow
    for (int i = 0; i < 2 * n - 1; i++) {
        cout << "* ";
    }
    cout << endl;
}

int main() {
    int n;
    cout << "Enter the number of rows: ";
    cin >> n;
    printArrowPattern(n);
    return 0;
}
