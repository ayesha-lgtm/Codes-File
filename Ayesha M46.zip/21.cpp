        E
       D D
      C   C
     B     B
    A       A
    
#include <iostream>
using namespace std;

int main() {
    int n = 5; // Number of rows
    char ch = 'E'; // Starting character

    for (int i = 1; i <= n; i++) {
        // Print leading spaces
        for (int j = 1; j <= n - i; j++) {
            cout << " ";
        }

        // Print the character
        cout << ch;

        // Print spaces in between
        if (i > 1) {
            for (int j = 1; j <= 2 * (i - 1) - 1; j++) {
                cout << " ";
            }
            cout << ch;
        }

        // Move to the next line
        cout << endl;

        // Decrement the character
        ch--;
    }

    return 0;
}