510152025
49141924
38131823
27121722
16111621

#include <iostream>
using namespace std;

int main() {
    int count = 51;
    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= 5 + i; j++) {
            if (j == 1 || j == 3) {
                cout << count;
            } else {
                cout << count - 40;
                count--;
            }
        }
        count -= 11;
        cout << endl;
    }

    return 0;
}