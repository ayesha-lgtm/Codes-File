110112021
29121922
38131823
47141724
56151625

#include <iostream>
using namespace std;

int main() {
    int count = 10;
    for (int i = 1; i <= 5; i++) {
        cout << count;
        count += i;
        for (int j = 1; j <= 4; j++) {
            cout << count;
            count++;
        }
        cout << endl;
        count = 10 + 18 * i;
    }

    return 0;
}
