
#include <iostream>
using namespace std;

double volumeOfCone(double radius, double height) {
    const double pi = 3.14159;
    return (1.0/3) * pi * radius * radius * height;
}

int main() {
    double radius, height;
    cout << "Enter the radius of the cone: ";
    cin >> radius;
    cout << "Enter the height of the cone: ";
    cin >> height;
    cout << "Volume of the cone: " << volumeOfCone(radius, height) << endl;
    return 0;
}
