
#include <iostream>
using namespace std;

int subtract(int a, int b) {
    return a + (~b + 1);
}

int main() {
    int a, b;
    cout << "Enter first number: ";
    cin >> a;
    cout << "Enter second number: ";
    cin >> b;
    cout << "Difference: " << subtract(a, b) << endl;
    return 0;
}
