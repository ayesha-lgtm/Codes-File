   A       A
    B     B
     C   C
      D D
       E
      

#include <iostream>
using namespace std;

int main() {
    int n = 5; // Number of rows
    char ch = 'A'; // Starting character

    for (int i = n; i >= 1; i--) {
        // Print leading spaces
        for (int j = n; j > i; j--) {
            cout << " ";
        }

        // Print the left character
        cout << ch;

        // Print spaces between characters
        for (int j = 1; j < 2 * (i - 1); j++) {
            cout << " ";
        }

        // Print the right character (if not the last row)
        if (i != 1) {
            cout << ch;
        }

        // Move to the next line
        cout << endl;

        // Increment the character
        ch++;
    }

    return 0;
}