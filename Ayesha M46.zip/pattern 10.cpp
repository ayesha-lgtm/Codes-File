112131
122232
132333
122434
152535

#include <iostream>
using namespace std;

int main() {
    for (int i = 1; i <= 5; i++) {
        int num = i;
        if (i == 4) num = 2;
        for (int j = 1; j <= 5; j++) {
            cout << num;
            if (j % 2 == 0) num++;
        }
        cout << endl;
    }

    return 0;
}