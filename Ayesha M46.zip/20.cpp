        A
       B B
      C   C
     D     D
    E       E
    
#include <iostream>
using namespace std;

int main() {
    int n = 5; // Number of rows
    char ch = 'A'; // Starting character

    for (int i = 1; i <= n; i++) {
        // Print leading spaces
        for (int j = 1; j <= n - i; j++) {
            cout << " ";
        }

        // Print the first character
        cout << ch;

        // Print spaces between characters
        for (int j = 1; j < 2 * (i - 1); j++) {
            cout << " ";
        }

        // Print the second character (except for the first row)
        if (i != 1) {
            cout << ch;
        }

        // Move to the next character
        ch++;

        cout << endl;
    }

    return 0;
}