12345
246810
3691215
48121620
510152025

#include <iostream>
using namespace std;

int main() {
    int count = 1;

    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= 5 + i; j++) {
            cout << count;
            count++;
        }
        cout << endl;
    }

    return 0;
}
