
#include <iostream>
using namespace std;

class Grandparent {
    public:
        void inheritance() {
            cout << "Grandparent's inheritance" << endl;
        }
};

class Parent1 : virtual public Grandparent {
    public:
        void parent1() {
            cout << "Parent1's property" << endl;
        }
};

class Parent2 : virtual public Grandparent {
    public:
        void parent2() {
            cout << "Parent2's property" << endl;
        }
};

class Child : public Parent1, public Parent2 {
    public:
        void child() {
            cout << "Child's property" << endl;
        }
};

int main() {
    Child c;
    c.inheritance();
    c.parent1();
    c.parent2();
    c.child();
    return 0;
}
