        1
       2 2
      3   3
     4     4
    5       5
    
#include <iostream>
using namespace std;

int main() {
    int n = 5; // Number of rows

    for (int i = 1; i <= n; i++) {
        // Print leading spaces
        for (int j = 1; j <= n - i; j++) {
            cout << " ";
        }

        // Print the first number
        cout << i;

        // Print spaces between numbers
        for (int j = 1; j < 2 * (i - 1); j++) {
            cout << " ";
        }

        // Print the second number (except for the first row)
        if (i != 1) {
            cout << i;
        }

        cout << endl;
    }

    return 0;
}