
#include <iostream>
using namespace std;

void printMessage(string message, string prefix = "Default: ") {
    cout << prefix << message << endl;
}

int main() {
    printMessage("Hello, World!");
    printMessage("Hello, World!", "Custom: ");
    return 0;
}
