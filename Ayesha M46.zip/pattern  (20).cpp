
#include <iostream>
using namespace std;

int main() {
    int rows;
    cout << "Enter the number of rows: ";
    cin >> rows;

    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= rows - i; j++) {
            cout << " ";
        }
        for (int k = 1; k <= i; k++) {
            if ((i + k) % 4 == 0) {
                cout << "$ ";
            } else if ((i + k) % 3 == 0) {
                cout << "^ ";
            } else if ((i + k) % 2 == 0) {
                cout << "* ";
            } else {
                cout << "# ";
            }
        }
        cout << endl;
    }

    return 0;
}
