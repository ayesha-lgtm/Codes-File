   5       5
    4     4
     3   3
      2 2
       1
      
#include <iostream>
using namespace std;

int main() {
    int n = 5; // Number of rows

    for (int i = n; i >= 1; i--) {
        // Print leading spaces
        for (int j = n; j > i; j--) {
            cout << " ";
        }

        // Print the left number
        cout << i;

        // Print spaces between numbers
        for (int j = 1; j < 2 * (i - 1); j++) {
            cout << " ";
        }

        // Print the right number (if not the last row)
        if (i != 1) {
            cout << i;
        }

        // Move to the next line
        cout << endl;
    }

    return 0;
}