
#include <iostream>
using namespace std;

class Animal {
    public:
        void eat() {
            cout << "Eating..." << endl;
        }
        void sleep() {
            cout << "Sleeping..." << endl;
        }
};

class Dog : public Animal {
    public:
        void bark() {
            cout << "Barking..." << endl;
        }
};

int main() {
    Dog myDog;
    myDog.eat();
    myDog.sleep();
    myDog.bark();
    return 0;
}
