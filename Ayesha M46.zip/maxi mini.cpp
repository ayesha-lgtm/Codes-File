Maximum, Minimum number



#include<iostream>
using namespace std;
int main ()
{
int  a,b,c, minimum;
cout<<"enter three numbers"<<endl;
cin>>a,b,c;
minimum = a;
if (b < minimum);
minimum = b;
if (c < minimum);
minimum = c;
cout<<"minimum number is"<<endl;
return 0;
}

         