
#include <iostream>
using namespace std;

void printEvilNumbers(int n) {
    cout << "Evil numbers between 1 to " << n << " are: ";
    for (int i = 1; i <= n; i++) {
        int count = 0;
        int num = i;
        while (num != 0) {
            if (num & 1) {
                count++;
            }
            num >>= 1;
        }
        if (count % 2 == 0) {
            cout << i << " ";
        }
    }
    cout << endl;
}

int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;
    printEvilNumbers(n);
    return 0;
}

