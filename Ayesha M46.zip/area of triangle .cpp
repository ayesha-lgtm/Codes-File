
#include <iostream>
using namespace std;

int main() {
    float base, height;

    cout << "Enter the base of the triangle: ";
    cin >> base;

    cout << "Enter the height of the triangle: ";
    cin >> height;

    float area = 0.5 * base * height;

    cout << "The area of the triangle is: " << area << endl;

    return 0;
}
