16111621
27121722
38131823
49141924
510152025

#include <iostream>
using namespace std;

int main() {
    int count = 16;
    for (int i = 1; i <= 5; i++) {
        for (int j = 1; j <= 5 + i; j++) {
            if (j == 1 || j == 3) {
                cout << count;
            } else {
                cout << count + 1;
                count++;
            }
        }
        count += 10;
        cout << endl;
    }

    return 0;
}
