        E
       D F
      C   G
     B     H
    A       I
    
#include <iostream>
using namespace std;

int main() {
    int n = 5; // Number of rows
    char ch1 = 'E'; // Starting character for the left side
    char ch2 = 'E'; // Starting character for the right side

    for (int i = 1; i <= n; i++) {
        // Print leading spaces
        for (int j = 1; j <= n - i; j++) {
            cout << " ";
        }

        // Print the left character
        cout << ch1;

        // Print spaces in between
        if (i > 1) {
            for (int j = 1; j <= 2 * (i - 1) - 1; j++) {
                cout << " ";
            }
            // Print the right character
            cout << ch2;
        }

        // Move to the next line
        cout << endl;

        // Update characters for the next row
        ch1--;
        ch2++;
    }

    return 0;
}