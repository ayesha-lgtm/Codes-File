
#include <iostream>
using namespace std;

int main() {
    const float pi = 3.14159;
    float radius;

    cout << "Enter the radius of the circle: ";
    cin >> radius;

    float area = pi * radius * radius;

    cout << "The area of the circle is: " << area << endl;

    return 0;
}
