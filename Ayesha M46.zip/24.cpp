   1       1
    2     2
     3   3
      4 4
       5
      
      #include <iostream>
using namespace std;

int main() {
    int n = 5; // Number of rows

    // Loop for the upper part of the pattern
    for (int i = 1; i <= n; i++) {
        // Print leading spaces
        for (int j = 1; j < i; j++) {
            cout << " ";
        }
        // Print the number
        cout << i;
        // Print spaces between the numbers
        for (int j = 1; j <= 2 * (n - i) - 1; j++) {
            cout << " ";
        }
        // Print the number again, except for the last row
        if (i != n) {
            cout << i;
        }
        // Move to the next line
        cout << endl;
    }

    return 0;
}