print 0 to 100


#include<iostream>
using namespace std;
int main()
{
 int a =0;
 do
  {
  cout<< a <<endl;
 a=a+1;// a++
  } while(a<=100);
  return 0;
  }