   *       *
    *     *
     *   *
      * *
       *
       #include <iostream>
using namespace std;

int main() {
    int n = 5; // Number of rows

    for (int i = 1; i <= n; i++) {
        // Print leading spaces
        for (int j = 1; j < i; j++) {
            cout << " ";
        }

        // Print the first star
        cout << "*";

        // Print spaces in between
        for (int j = 1; j <= 2 * (n - i) - 1; j++) {
            cout << " ";
        }

        // Print the second star (except for the last row)
        if (i != n) {
            cout << "*";
        }

        // Move to the next line
        cout << endl;
    }

    return 0;
}