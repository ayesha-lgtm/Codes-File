
#include <iostream>
using namespace std;

int main() {
    int rows;
    cout << "Enter the number of rows: ";
    cin >> rows;

    int a = 0, b = 1;
    for (int i = 1; i <= rows; i++) {
        for (int j = 1; j <= i; j++) {
            cout << a << " ";
            int temp = a;
            a = b;
            b = temp + b;
        }
        cout << endl;
    }

    return 0;
}
