   A       I
    B     H
     C   G
      D F
       E
      
      #include <iostream>
using namespace std;

int main() {
    // Define the number of rows in the diamond
    int rows = 5;

    // Print the top half of the diamond
    for (int i = 0; i < rows; i++) {
        // Print leading spaces
        for (int j = 0; j < i; j++) {
            cout << " ";
        }

        // Print the first letter
        cout << char('A' + i);

        // Print spaces between the letters
        for (int j = 0; j < 2 * (rows - i - 1) - 1; j++) {
            cout << " ";
        }

        // Print the second letter (if not the middle row)
        if (i != rows - 1) {
            cout << char('I' - i);
        }

        // Move to the next line
        cout << endl;
    }

    // Print the bottom half of the diamond
    for (int i = rows - 2; i >= 0; i--) {
        // Print leading spaces
        for (int j = 0; j < i; j++) {
            cout << " ";
        }

        // Print the first letter
        cout << char('A' + i);

        // Print spaces between the letters
        for (int j = 0; j < 2 * (rows - i - 1) - 1; j++) {
            cout << " ";
        }

        // Print the second letter
        cout << char('I' - i);

        // Move to the next line
        cout << endl;
    }

    return 0;
}