
#include <iostream>
using namespace std;

class Animal {
    public:
        virtual void sound() {
            cout << "The animal makes a sound." << endl;
        }
};

class Dog : public Animal {
    public:
        void sound() override {
            cout << "The dog barks." << endl;
        }
};

class Cat : public Animal {
    public:
        void sound() override {
            cout << "The cat meows." << endl;
        }
};

int main() {
    Animal* animal = new Animal();
    Animal* dog = new Dog();
    Animal* cat = new Cat();

    animal->sound();
    dog->sound();
    cat->sound();

    delete animal;
    delete dog;
    delete cat;

    return 0;
}
